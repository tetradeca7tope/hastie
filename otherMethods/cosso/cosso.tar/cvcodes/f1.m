function f = f1(x)

     f = x;
