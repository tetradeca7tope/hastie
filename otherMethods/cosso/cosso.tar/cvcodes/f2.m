function f = f2(x)

     f = (2 * x - 1).^2;
