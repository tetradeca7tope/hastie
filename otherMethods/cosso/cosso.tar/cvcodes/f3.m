function f = f3(x)

     f = sin(2 * pi * x) ./(2 - sin(2 * pi * x));
