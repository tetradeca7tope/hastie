function f = f4(x)

     f = 0.1 * sin (2 * pi * x) + 0.2 * cos(2 * pi * x) + 0.3 * (sin(2 * pi * x)).^2 + 0.4 * (cos(2 * pi * x)).^3 + 0.5 * (sin(2 * pi * x)).^3;
